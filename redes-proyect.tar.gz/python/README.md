
############################
Servidor: receive.py
Puerto de comunicacion: 5005
IP Publica: 132.248.29.124 (Temporal)

############################
Base de datos SQLlite3
Nombre: arduino.db
Tabla: arduino (4 campos)

CREATE TABLE IF NOT EXISTS arduino (heart_rate text, temperature text, humidity text

############################
Cliente: Simulador para el envio de datos: send.py


